package com.saigopl.movie_hub.helpUtils;

public class Utils {

    public static final String apiKey = "aaa6d0289078c31a06c76d4c39d1c33b";
    public static final String language = "en-US";



}
